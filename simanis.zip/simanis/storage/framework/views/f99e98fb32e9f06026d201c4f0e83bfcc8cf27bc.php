<?php $__env->startSection('content'); ?>

<div align = "center" class = "container">
        <br>
    <h3>Selamat Datang | Welcome</h3>
        <br>
        <br>
    <h5 align = "left">Website ini bertujuan agar masyarakat dapat memperoleh dan memanfaatkan informasi dari hasil evaluasi atas penyelenggaraan jasa telekomunikasi.</h5>       
    <h5 align = "left">Silahkan masuk dengan mengisi username dan password atau masuk sebagai tamu.</h5>
        <br>
        <br>
    <h5 align = "left">This application aims to enable people to obtain and use information from the results of evaluation of telecommunications services.</h5>
    <h5 align = "left">Please login by filling in your username and password or login as a guest</h5>
        <br>
        <br>
    <h3>Terima Kasih | Thank You</h3>
        <br>
    <h6>Tim Direktorat Pengendalian Pos dan Informatika</h6>
    <h6>Ditjen PPI - Kominfo</h6>
    <br>
    <a class = "btn btn-primary btn-lg"  href = "/perusahaan">Login</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simanis\resources\views/simanis/landing_page.blade.php ENDPATH**/ ?>