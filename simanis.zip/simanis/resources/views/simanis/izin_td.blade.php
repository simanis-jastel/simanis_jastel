@extends('layout.app')

@section('content')
<br>
<h3 align = "center">Pemilik Izin Teleponi Dasar (TD)</h3>
<br>
<div class = "container">
        <table class = "table tabe-bordered">
                <tr>
                    <th>No.</th>
                    <th>Perusahaan</th>
                    <th>Nomor Izin</th>
                    <th>Tahun Izin</th>
                    <th>Jenis Izin</th>
                </tr>      
            <?php
                $conn = mysqli_connect("localhost","root","","dbsimanis");
                    if ($conn -> connect_error) {
                        die("Connection Failed:". $conn -> connect_errror);
                    }
                $sql = "SELECT id, nama_perusahaan, nomor_izin, tahun_izin, jenis_izin from tb_td";
                    $result = $conn -> query($sql);
                        
                        if ($result -> num_rows > 0){
                            while ($row = $result -> fetch_assoc()){
                                echo "<tr><td>".$row["id"] . "</td><td>" . $row["nama_perusahaan"] . "</td><td>" . $row["nomor_izin"] . "</td><td>" . 
                                $row["tahun_izin"] . "</td><td>" . $row["jenis_izin"] . "</td></tr>";
                            }
                                echo "</table>";
                            }
                            else {
                                echo "0 result";
                            }
                            $conn -> close();
            ?>
        </table>

@endsection