@extends('layout.app')

@section('content')
<br>
<h3 align = "center">Pemilik Izin Call Credit (CCD)</h3>
<br>
<div class = "container">
    <table class = "table tabe-bordered">
            <tr>
                <th>No.</th>
                <th>Perusahaan</th>
                <th>Nomor Izin</th>
                <th>Tahun Izin</th>
                <th>Jenis Izin</th>
            </tr>      
        <?php
            $conn = mysqli_connect("localhost","root","","db_simanis_jastel");
                if ($conn -> connect_error) {
                    die("Connection Failed:". $conn -> connect_errror);
                }
        ?>
    </table>

</div>

@endsection