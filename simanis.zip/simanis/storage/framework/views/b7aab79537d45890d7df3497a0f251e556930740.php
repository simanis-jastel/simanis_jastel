<?php $__env->startSection('content'); ?>
<br>
<h3 align = "center">Pemilik Izin Premium Call (PC)
<br>
<div class = "container">
        <table class = "table tabe-bordered">
                <tr>
                    <th>No.</th>
                    <th>Perusahaan</th>
                    <th>Nomor Izin</th>
                    <th>Tahun Izin</th>
                    <th>Jenis Izin</th>
                </tr> 
        </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simanis\resources\views/simanis/izin_pc.blade.php ENDPATH**/ ?>