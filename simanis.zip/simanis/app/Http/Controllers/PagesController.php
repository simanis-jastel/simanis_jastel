<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function index(){
        $data = array(
            'title' => 'Simanis Jastel',
            'tipeperizinan' => ['TD','ISP','NAP','SKD','CC','ITKP','PC','CP','CCD'],
            'perusahaan' => ['Perusahaan A', 'Perusahaan B', 'Perusahaan C','D', 'E', 'F', 'G'],
            'tanggal' => ['5 Mei, 12 Mei', '22 Mei'],
            'status' => ['Aktif', 'Dicabut', 'Aktif']
        );
        return view('simanis.index')->with ($data);
    }

    public function login(){
        return view('simanis.login');
    }

    public function perusahaan(){
        $data = array(
            'tipeperizinan' => ['TD','ISP'],
            'nomorizin' => ['1111','2222'],
            'tanggal' => ['12 Mei','28 Mei'],
            'statusizin' => ['Aktif','Sudah Dicabut']
        );
        return view('simanis.perusahaan') -> with($data);
    }

    public function izin_td(){
        return view('simanis.izin_td');
    }

    public function izin_isp(){
        return view('simanis.izin_isp');
    }

    public function izin_nap(){
        return view('simanis.izin_nap');
    }

    public function izin_skd(){
        return view('simanis.izin_skd');
    }

    public function izin_ccd(){
        return view('simanis.izin_ccd');
    }

    public function izin_cc(){
        return view('simanis.izin_cc');
    }

    public function izin_itkp(){
        return view('simanis.izin_itkp');
    }

    public function izin_pc(){
        return view('simanis.izin_pc');
    }

    public function izin_cp(){
        return view('simanis.izin_cp');
    }

    public function landing_page(){
        return view('simanis.landing_page');
    }

    //Simanis_2//
    public function index_2(){
        return view('simanis_2.index_2');
    }

    public function izin_td_2(){
        return view('simanis_2.izin_td_2');
    }

    public function izin_isp_2(){
        return view('simanis_2.izin_isp_2');
    }
    public function izin_nap_2(){
        return view('simanis_2.izin_nap_2');
    }

    public function izin_skd_2(){
        return view('simanis_2.izin_skd_2');
    }

    public function izin_ccd_2(){
        return view('simanis_2.izin_ccd_2');
    }

    public function izin_cc_2(){
        return view('simanis_2.izin_cc_2');
    }

    public function izin_itkp_2(){
        return view('simanis_2.izin_itkp_2');
    }

    public function izin_pc_2(){
        return view('simanis_2.izin_pc_2');
    }

    public function izin_cp_2(){
        return view('simanis_2.izin_cp_2');
    }

}
