@extends('layout.app')

@section('content')
<br>
    <h1>Perusahaan A</h1>
<br>
        @if(count($tipeperizinan) > 0)
            <ul class = "list-group">
                @foreach ($tipeperizinan as $tipeperizinan)
                    <li class = "list-group-item">{{$tipeperizinan}}</li>
                @endforeach
                    <br>

                @foreach ($nomorizin as $nomorizin)
                    <li class = "list-group-item">{{$nomorizin}}</li>
                @endforeach
                    <br>

                @foreach ($tanggal as $tanggal)
                    <li class = "list-group-item">{{$tanggal}}</li>
                @endforeach
                    <br>

                @foreach ($statusizin as $statusizin)
                    <li class = "list-group-item">{{$statusizin}}</li>
                @endforeach   
                    <br>
            </ul>
        @endif

        <div class = "container">   
                <table class = "table table-bordered">
                    <tr>
                      <th>No.</th>
                      <th>Perusahaan</th>
                      <th>Nomor Izin</th>
                      <th>Tahun Izin</th>
                      <th>Jenis Izin</th>
                    </tr>
                    <?php
                    $conn = mysqli_connect("localhost","root","","dbsimanis");
                    if ($conn -> connect_error) {
                      die("Connection Failed:". $conn -> connect_errror);
                    }
                
                    $sql = "SELECT id, perusahaan, nomor_izin, tahun_izin, jenis_izin from tb_izin_1";
                    $result = $conn -> query($sql);
                
                    if ($result -> num_rows > 0){
                      while ($row = $result -> fetch_assoc()){
                        echo "<tr><td>".$row["id"] . "</td><td>" . $row["perusahaan"] . "</td><td>" . $row["nomor_izin"] . "</td><td>" . 
                          $row["tahun_izin"] . "</td><td>" . $row["jenis_izin"] . "</td></tr>";
                      }
                      echo "</table>";
                    }
                    else {
                      echo "0 result";
                    }
                    $conn -> close();
                    
                    ?>
                  </table>
            </div>
@endsection