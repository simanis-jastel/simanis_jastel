<?php $__env->startSection('content'); ?>

<br>
    <h1 class = "display-5" align = "center">INFO PUBLIK</h1>
    <h1 class = "display-5" align = "center">HASIL EVALUASI PENYELENGGARAAN JASA TELEKOMUNIKASI</h1>
<br>
<br>

<div class = "container" align = "center">
      <h3>Informasi Per Izin</h3>
          <a href="izin_td_2" class="btn btn-info btn-lg" role="button">TD</a>
          <a href="izin_isp_2" class="btn btn-info btn-lg" role="button">ISP</a>
          <a href="izin_nap_2" class="btn btn-info btn-lg" role="button">NAP</a>
          <a href="izin_skd_2" class="btn btn-info btn-lg" role="button">SKD</a>
          <a href="izin_ccd_2" class="btn btn-info btn-lg" role="button">CCD</a>
          <a href="izin_cc_2" class="btn btn-info btn-lg" role="button">CC</a>
          <a href="izin_itkp_2" class="btn btn-info btn-lg" role="button">ITKP</a>
          <a href="izin_pc_2" class="btn btn-info btn-lg" role="button">PC</a>
          <a href="izin_cp_2" class="btn btn-info btn-lg" role="button">CP</a>
</div>

<br>
<br>

<div class = "container" align = "center">
    <h3>Informasi Per Perusahaan</h3>
        <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Dropdown Example
                <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li><a href="perusahaan">Perusahaan A</a></li>
                <li><a href="#">Perusahaan B</a></li>
                <li><a href="#">Perusahaan C</a></li>
            </ul>
        </div>
</div>

<br>
<br>

<div class = "container" align = "center">
    <h3>Informasi Per Wilayah</h3>
        <div class="dropdown">
            <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Dropdown Example
                <span class="caret"></span></button>
            <ul class="dropdown-menu">
                <li><a href="#">HTML</a></li>
                <li><a href="#">CSS</a></li>
                <li><a href="#">JavaScript</a></li>
            </ul>
        </div>
</div>
<br>

<table class = "table">
    <thead>
        <tr>
            <td>No.</td>
            <td>Nama Perusahaan</td>
            <td colspan="1">Action</td>
        </tr>
    </thead>
        <tbody>
          
            <tr>
            <td>1</td>
            <td>Perusahaan A</td>
                <td>
                    <a></a>
                    <button type = "button" class = "btn btn-success">Detail</button>
                </td>
            </tr>
       
        </tbody>
</table>

<?php
$conn = mysqli_connect("localhost","root","","dbsimanis");
    if ($conn -> connect_error) {
        die("Connection Failed:". $conn -> connect_errror);
    }
$sql = "SELECT nama_perusahaan from perusahaans";
    $result = $conn -> query($sql);
        
        if ($result -> num_rows > 0){
            while ($row = $result -> fetch_assoc()){
                echo "<tr><td>". $row["nama_perusahaan"] . "</td></tr>";
            }
                echo "</table>";
            }
            else {
                echo "0 result";
            }
            $conn -> close();
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simanis\resources\views/simanis_2/index_2.blade.php ENDPATH**/ ?>