<?php

Route::get('/', 'PagesController@index');
Route::get('/login', 'PagesController@login');
Route::get('/perusahaan','PagesController@perusahaan');


Route::get('/izin_td','PagesController@izin_td');
Route::get('/izin_isp','PagesController@izin_isp');
Route::get('/izin_nap','PagesController@izin_nap');
Route::get('/izin_skd','PagesController@izin_skd');
Route::get('/izin_ccd','PagesController@izin_ccd');
Route::get('/izin_cc','PagesController@izin_cc');
Route::get('/izin_itkp','PagesController@izin_itkp');
Route::get('/izin_pc','PagesController@izin_pc');
Route::get('/izin_cp','PagesController@izin_cp');
Route::get('/landing_page','PagesController@landing_page');

//Simanis 2//
Route::get('/2', 'PagesController@index_2');
Route::get('/izin_td_2','PagesController@izin_td_2');
Route::get('/izin_isp_2','PagesController@izin_isp_2');
Route::get('/izin_nap_2','PagesController@izin_nap_2');
Route::get('/izin_skd_2','PagesController@izin_skd_2');
Route::get('/izin_ccd_2','PagesController@izin_ccd_2');
Route::get('/izin_cc_2','PagesController@izin_cc_2');
Route::get('/izin_itkp_2','PagesController@izin_itkp_2');
Route::get('/izin_pc_2','PagesController@izin_pc_2');
Route::get('/izin_cp_2','PagesController@izin_cp_2');