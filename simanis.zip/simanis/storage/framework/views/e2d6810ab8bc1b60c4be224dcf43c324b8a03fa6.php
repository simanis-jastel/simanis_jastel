<!-- Footer -->
<footer class="page-footer font-small teal pt-4 bg-dark">

        <!-- Footer Text -->
        <div class="container">
      
          <!-- Grid row -->
          <div class="row">
      
            <!-- Grid column -->
            <div class="col-sm-9">
      
              <!-- Content -->
              <span class = "text-muted">Direktorat Pengendalian Pos dan Informatika Ditjen PPI - Kominfo</span>
                    <br>
                    <br>
                    <span class = "text-muted">Graha PPI</span>
                    <br>
                    <span class = "text-muted">Jl. Abdul Muis, No. 8, Gambir, DKI Jakarta</span>
                    <br>
                    <br>
      
            </div>
            <!-- Grid column -->
      
            <hr class="clearfix w-100 d-md-none pb-3">
      
            <!-- Grid column -->
            <div class="col-sm-3">
      
              <!-- Content -->
              <span class = "text-muted">Hubungi Kami | Contact Us</span>
                    <br>
                    <br>
                    <span class = "text-muted">021-34832532</span>
                    <br>
                    <span class = "text-muted">jasatel@mail.kominfo.go.id</span>
      
            </div>
            <!-- Grid column -->
      
          </div>
          <!-- Grid row -->
      
        </div>
        <!-- Footer Text -->
      
      </footer>
      <!-- Footer -->
<?php /**PATH C:\xampp\htdocs\simanis\resources\views/inc/footer.blade.php ENDPATH**/ ?>