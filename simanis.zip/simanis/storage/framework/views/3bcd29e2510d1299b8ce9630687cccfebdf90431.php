<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?> ">
    <title>Simanis Jastel</title>
</head>
<body>
    <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class = "container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <br>      
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\simanis\resources\views/layout/app.blade.php ENDPATH**/ ?>