<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="{{asset('css/app.css')}} ">
    <title>Simanis Jastel</title>
</head>
<body>
    @include('inc.navbar')
        <div class = "container">
            @yield('content')
        </div>
        <br>      
    @include('inc.footer')
</body>
</html>