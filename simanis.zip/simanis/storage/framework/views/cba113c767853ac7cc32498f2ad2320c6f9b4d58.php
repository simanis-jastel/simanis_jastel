<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class = "container">
        <div class = "navbar-header">
            
            <span style="color:white;" href="https://www.kominfo.go.id/">Kementrian Kominfo</span> 
        </div>
        <div class = "navbar-header">
            
            <span style="color:white;" href="/">Simanis Jastel</span>          
        </div>
    </div>
</nav>

<?php /**PATH C:\xampp\htdocs\simanis\resources\views/inc/navbar.blade.php ENDPATH**/ ?>