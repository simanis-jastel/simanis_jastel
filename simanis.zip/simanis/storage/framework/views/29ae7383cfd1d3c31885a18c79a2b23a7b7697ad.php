<?php $__env->startSection('content'); ?>
<br>
<h3 align = "center">Pemilik Izin Network Access Point (NAP)</h3>
<br>
<div class = "container">
    <table class = "table tabe-bordered">
            <tr>
                <th>No.</th>
                <th>Perusahaan</th>
                <th>Nomor Izin</th>
                <th>Tahun Izin</th>
                <th>Jenis Izin</th>
            </tr>      
        <?php
            $conn = mysqli_connect("localhost","root","","db_simanis_jastel");
                if ($conn -> connect_error) {
                    die("Connection Failed:". $conn -> connect_errror);
                }
        ?>
    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simanis\resources\views/simanis_2/izin_nap_2.blade.php ENDPATH**/ ?>