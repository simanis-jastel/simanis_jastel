<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePerusahaansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('perusahaans', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('nama_perusahaan');
            $table->string('nomor_izin');
            $table->integer('tahun_izin');
            $table->string('tipe_izin');
            $table->string('jalan_perusahaan');
            $table->string('kota_perusahaan');
            $table->string('provinsi_perusahaan');
            $table->integer('telepon_perusahaan');
            $table->integer('fax_perusahaan');
            $table->string('web_perusahaan');
            $table->string('email_perusahaan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('perusahaans');
    }
}
