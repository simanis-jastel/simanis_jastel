@extends('layout.app')

@section('content')
<br>
<h3 align = "center">Pemilik Izin Premium Call (PC)</h3>
<br>
<div class = "container">
        <table class = "table tabe-bordered">
                <tr>
                    <th>No.</th>
                    <th>Perusahaan</th>
                    <th>Nomor Izin</th>
                    <th>Tahun Izin</th>
                    <th>Jenis Izin</th>
                </tr> 
        </table>
</div>
@endsection