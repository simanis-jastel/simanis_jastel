<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Perusahaan extends Model
{
    protected $fillable = ['nama_perusahaan','nomor_izin','tahun_izin','tipe_izin','jalan_perusahaan','kota_perusahaan','provinsi_perusahaan','telepon_perusahaan','fax_perusahaan','web_perusahaan','email_perusahaan'];
}
